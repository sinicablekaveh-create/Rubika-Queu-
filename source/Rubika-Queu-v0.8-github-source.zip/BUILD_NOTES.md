# Rubika-Queu Android build notes (v0.8)

This is a complete Android *source* package extracted from the uploaded v0.8 archive and adapted for Gradle; it is **not a built APK**. Android SDK and Gradle are required to compile it.

Do not publish the signing key to GitHub. Keep `signing/test-signing.p12` private and add its base64 content to GitHub Actions secret `RUBIKA_TEST_KEYSTORE_BASE64`. The signing key originally supplied in the uploaded ZIP matches the certificate in the earlier Rubika-Queue-test.apk (SHA-256: 87:47:83:8D:91:3E:2F:0F:58:DC:66:E4:32:EB:37:53:BC:82:6E:6A:3F:7E:23:EA:F6:BB:79:9C:D6:3A:F2:8B).

Local Android build: install Android SDK API 35, build-tools 35.0.0, Java 17 and Gradle 8.9. Place the PKCS12 key locally in `signing/test-signing.p12` and run `gradle wrapper --gradle-version 8.9 && ./gradlew assembleDebug`. For the bundled legacy key, alias `test` and password `android` were independently verified.

GitHub build: Commit this tree *without* the private signing key; `.github/workflows/build-apk.yml` builds and verifies signed `Rubika-Queu-v0.8-test-signed.apk` after source import and required signing secret setup. On-device authentication, actual Rubika API messaging and installation are NOT validated by CI alone.
